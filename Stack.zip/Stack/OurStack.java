/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: OurStack.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartB;

public class OurStack<T> implements StackInterface<T> {
    Node handle; // topNode aka firstNode
    //private int numberOfLetter;


    private class Node{
        T data;
        Node next;
        Node(T data, Node next){
            this.data = data;
            this.next = next;
        }Node (T data){
            this(data,null);
        }
    }

    public OurStack() {

    }public static boolean checkBalance(String Text){
        String temp;
        String mainText="";
        for (int i=0;i<Text.length();i++){
            if (Character.isLetter(Text.charAt(i))||Character.isDigit(Text.charAt(i))){

                temp=  Character.toString(  Text.charAt(i));
                mainText= mainText+temp;

            }

        }

        mainText=mainText.toLowerCase();
        //System.out.println("mainTex: "+mainText);

        StackInterface<Character> bag = new OurStack<>();
        int numberOfLetter= mainText.length();

        int midpoint;
        boolean isEven ;
        boolean isBalance ;
        char currentLetter;
        if (numberOfLetter%2==1){
            midpoint = (numberOfLetter-1)/2;
            isEven=false;
        }else{
            midpoint= numberOfLetter/2;
            isEven=true;
        }
        //System.out.println(midpoint + " "+numberOfLetter);
        if (!isEven){

            /*   0  1  2  3  4  5  6  7  8    numberOfLetter = 9  midpoint = 4
             *    A  B  C  D  E  D  C  B  A
             *    ----------     ----------
             *    push        no    pop
             *
             *
             *
             * */

            for (int i=0;i<midpoint;i++){
                currentLetter = mainText.charAt(i);
                bag.push(currentLetter);
                //


            }for (int j=midpoint+1;j<numberOfLetter;j++) {
                //currentLetter = mainText.charAt(j);
                if (bag.peek() == mainText.charAt(j)) {

                    bag.pop();
                    if (bag.pop() == null) {
                        break;
                    }

                }if (bag.peek() == null) {
                    break;
                }
            }

        }

        else {
            /*
              0  1  2  3  4  5   numberOfLetter = 6   midpoint = 3
            * A  B  C  C  B  A
            * */
            for (int i=0;i<midpoint;i++){
                currentLetter=mainText.charAt(i);
                bag.push(currentLetter);
            }for (int j=midpoint;j<numberOfLetter;j++){
                if(bag.peek()==mainText.charAt(j)) {
                    bag.pop();
                }
                if(bag.isEmpty()){
                    break;
                }


            }
        }

        //System.out.println("the peak is mt: "+bag.peek());
        //System.out.println("the peak is not mt: "+bag.peek());
        isBalance= bag.isEmpty();


        return isBalance;

    }

    @Override
    public void push(T newEntry) {
        Node currenNode = new Node(newEntry);
        currenNode.next = handle;
        handle = currenNode;
        // System.out.println("added successfully");
    }

    @Override
    public T peek() {
        if (handle!=null) {
            return handle.data;
        }else{
            //System.out.println("Your peek is null");
            //throw new EmptyStackException();
            return null;
        }

    }

    @Override
    public T pop() {
        T top= peek();
        assert (handle!=null): "The list is empty";
        if (!isEmpty()) {


            handle = handle.next;
        }
        return top;




    }

    @Override
    public boolean isEmpty() {
        return  handle==null;
    }

    @Override
    public void clear() {
        handle = null;
    }


}
